To start the tool, simply open the Toney.exe program. This program depends on
some DLL files installed on your computer. These files are provided by
Microsoft and, in many cases, installed by other applications you have
installed on your computer. If those files are missing, the tool will complain
about missing DLLs. If you get such an error message, run vcredist_x86.exe
program included in this package to install the DLLs.

More documentation is available from the Help menu of the tool.

The source code for this program is available at github:

  https://github.com/langtech/toney

